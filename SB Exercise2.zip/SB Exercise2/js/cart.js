var
  shoppingCart;

function ShoppingCart(){}

$().ready(function(){
  shoppingCart = new ShoppingCart();
  shoppingCart.init();
})

ShoppingCart.prototype.init = function(){
  $.getJSON('./cart.json', function(data){
    console.log("data");
  });
}