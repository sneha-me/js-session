var
  shoppingCart;

function ShoppingCart(){}

$().ready(function(){
  shoppingCart = new ShoppingCart();
  shoppingCart.init();
})

ShoppingCart.prototype.init = function(){
  $.getJSON('./cart.json', function(data){
    console.log("data");
    for(var i=0; i< data.productsInCart.length; i++){
      $('.shopping-table').append(
      "<div class='row'> <div class='col-md-4 col-sm-6 col-xs-6 image'>"
          + "<img src=../assets/T" +(i+1)+".jpg alt='T1 Shirt' /> </div> " +
       "<div class='col-xs-6 col-md-8'>" +
        "<div class='col-md-6 col-sm-6 desc'>" +
        "<div class='summary'>" +
              "<h4>" + data.productsInCart[i].p_variation +data.productsInCart[i].p_name +"</h4>" +
              "<p> Style #: " +data.productsInCart[i].p_style + "</p>" +
              "<p>Colour : " + data.productsInCart[i].p_selected_color.name + "</p> " + "<br/><br/>" +
              "<p> EDIT | <span class='ion-close-round'>  REMOVE</span> | SAVE FOR LATER</p></div>   </div>" +
        
        "<div class='col-md-2 col-sm-6 size'> <p>" + data.productsInCart[i].p_selected_size['code'] + "</p> </div>" +
        
        "<div class='col-md-2 col-sm-6 qty'> <p>" + data.productsInCart[i].p_quantity + "</p> </div>" +
        
        "<div class='col-md-2 col-sm-6 price'> <p>" + data.productsInCart[i].c_currency + data.productsInCart[i].p_price + "</p> </div>   </div>" +
        
      "</div> <hr/>"
      
      
      );
    }
  });
}